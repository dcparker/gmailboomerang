Getting Things Done for Gmail.

This doesn't expect you to keep an eye on your Tomorrow, Next Week, and Next Month boxes. Rather, it watches you put emails into these boxes and, like a boomerang, shuffles them back to your inbox on the appropriate day.

For example, you receive an email that you want to deal with next week. Simply label it "Next Week" and forget about it. GmailBoomerang will move it into the Tomorrow label after 6 days, and on the 7th day it will be moved into your Inbox.

Emails labeled Next Month will be moved to Next Week after 23 days, emails labeled Next Week will be moved to Tomorrow after 6 days, and emails labeled Tomorrow will be moved to the Inbox after 1 day.

The main purpose for this service is to allow you to fully EMPTY your inbox EVERY DAY. Enjoy an empty inbox!
